'use strict';

(function($){

  $(function() {

    $('#chart-container').orgchart({
      'data' : $('#ul-data')
    });

  });

})(jQuery);